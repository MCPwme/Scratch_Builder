import json
import tempfile
import unittest
import zipfile
from pathlib import Path

from scratch_builder.scratch_builder import validate_sb3


class ValidateSb3Tests(unittest.TestCase):
    def create_archive(self, project_data, asset_names):
        temp_dir = tempfile.TemporaryDirectory()
        archive_path = Path(temp_dir.name) / "test.sb3"
        with zipfile.ZipFile(str(archive_path), "w") as archive:
            archive.writestr("project.json", json.dumps(project_data))
            for asset_name in asset_names:
                archive.writestr(asset_name, b"asset")
        return temp_dir, archive_path

    def project_data(self, asset_name):
        return {
            "targets": [{
                "isStage": True,
                "name": "Stage",
                "costumes": [{"md5ext": asset_name}],
                "sounds": [],
            }],
            "monitors": [],
            "extensions": [],
            "meta": {"semver": "3.0.0", "vm": "0.2.0"},
        }

    def test_validates_referenced_assets_and_counts_archive_files(self):
        temp_dir, archive_path = self.create_archive(
            self.project_data("costume.svg"),
            ["costume.svg", "unused.dat"],
        )
        self.addCleanup(temp_dir.cleanup)

        result = validate_sb3(str(archive_path))

        self.assertTrue(result["valid"], result["errors"])
        self.assertEqual(result["info"]["素材文件数"], 1)
        self.assertEqual(result["info"]["ZIP 内文件数"], 3)

    def test_reports_missing_referenced_asset(self):
        temp_dir, archive_path = self.create_archive(
            self.project_data("missing.svg"),
            [],
        )
        self.addCleanup(temp_dir.cleanup)

        result = validate_sb3(str(archive_path))

        self.assertFalse(result["valid"])
        self.assertIn("引用的素材文件不存在: missing.svg", result["errors"])


if __name__ == "__main__":
    unittest.main()
