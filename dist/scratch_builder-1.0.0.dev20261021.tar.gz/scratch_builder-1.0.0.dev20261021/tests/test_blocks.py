import json
import tempfile
import unittest
import zipfile
from pathlib import Path

from scratch_builder import ScratchProject
from scratch_builder.scratch_builder import validate_sb3


class BlockBuilderTests(unittest.TestCase):
    def setUp(self):
        self.project = ScratchProject("Block tests")
        self.sprite = self.project.add_sprite(
            "Sprite", str(Path(__file__).parents[1] / "src" / "scratch_builder" / "empty.svg")
        )

    def test_control_callbacks_and_nested_reporters(self):
        self.sprite.create_variable("score", 0).create_list("items")
        script = self.sprite.when_flag_clicked()
        condition = script.greater_than(script.variable("score"), 0)
        script.repeat(
            3,
            lambda loop: loop.add_item_to_list("items", "x").move_steps(5)
        ).if_else(
            condition,
            lambda branch: branch.say("yes"),
            lambda branch: branch.think("no")
        )

        blocks = self.sprite.to_dict()["blocks"]
        by_opcode = {block["opcode"]: (block_id, block) for block_id, block in blocks.items()}
        repeat_id, repeat = by_opcode["control_repeat"]
        if_id, if_block = by_opcode["control_if_else"]
        self.assertEqual(repeat["inputs"]["SUBSTACK"][0], 2)
        loop_body_id = repeat["inputs"]["SUBSTACK"][1]
        self.assertEqual(blocks[loop_body_id]["opcode"], "data_addtolist")
        self.assertEqual(blocks[loop_body_id]["parent"], repeat_id)
        self.assertEqual(blocks[loop_body_id]["next"], by_opcode["motion_movesteps"][0])
        self.assertEqual(if_block["inputs"]["SUBSTACK"][1], by_opcode["looks_say"][0])
        self.assertEqual(if_block["inputs"]["SUBSTACK2"][1], by_opcode["looks_think"][0])
        self.assertEqual(blocks[if_block["inputs"]["CONDITION"][1]]["opcode"], "operator_gt")
        self.assertEqual(blocks[if_id]["next"], None)

    def test_events_broadcasts_and_menu_shadows(self):
        self.sprite.when_key_pressed("space").play_sound("pop")
        self.sprite.when_i_receive("ready").broadcast_and_wait("done")
        self.sprite.when_this_sprite_clicked().switch_costume("costume 1")
        self.sprite.when_i_start_as_a_clone().move_steps(1)

        target = self.sprite.to_dict()
        blocks = target["blocks"]
        opcodes = {block["opcode"] for block in blocks.values()}
        self.assertIn("event_whenkeypressed", opcodes)
        self.assertIn("event_whenbroadcastreceived", opcodes)
        self.assertIn("event_broadcastandwait", opcodes)
        self.assertIn("control_start_as_clone", opcodes)
        self.assertIn("sound_sounds_menu", opcodes)
        self.assertIn("looks_costume", opcodes)
        self.assertEqual(self.project.stage["broadcasts"], {"ready": "ready", "done": "done"})

    def test_project_adds_sprite_without_costume(self):
        sprite = self.project.add_sprite("No costume")
        self.assertIn(sprite, self.project.sprites)

    def test_sb3_export_with_nested_blocks(self):
        script = self.sprite.when_flag_clicked()
        script.forever(lambda body: body.wait(0.1).move_steps(1))

        with tempfile.TemporaryDirectory() as temp_dir:
            output_path = Path(temp_dir) / "test.sb3"
            self.project.save(str(output_path))
            result = validate_sb3(str(output_path))
            self.assertTrue(result["valid"], result["errors"])
            with zipfile.ZipFile(str(output_path)) as archive:
                project_data = json.loads(archive.read("project.json").decode("utf-8"))
            sprite_data = project_data["targets"][1]
            forever = next(
                block for block in sprite_data["blocks"].values()
                if block["opcode"] == "control_forever"
            )
            self.assertEqual(forever["inputs"]["SUBSTACK"][0], 2)


if __name__ == "__main__":
    unittest.main()
